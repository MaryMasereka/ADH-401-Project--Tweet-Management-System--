
package service;
 
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
 
@ApplicationPath("/service")
public class ApplicationConfig extends Application {
 
}